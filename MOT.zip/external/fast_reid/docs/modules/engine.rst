fastreid.engine
=========================

.. automodule:: fastreid.engine
    :members:
    :undoc-members:
    :show-inheritance:


fastreid.engine.defaults module
---------------------------------

.. automodule:: fastreid.engine.defaults
    :members:
    :undoc-members:
    :show-inheritance:

fastreid.engine.hooks module
---------------------------------

.. automodule:: fastreid.engine.hooks
    :members:
    :undoc-members:
    :show-inheritance:
