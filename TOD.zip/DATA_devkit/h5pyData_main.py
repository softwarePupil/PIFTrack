import pdb

import numpy as np
from tqdm import tqdm
from mmdet.datasets import build_dataset, build_dataloader
from mmcv import Config
import h5py
import os
import json
import torch.multiprocessing
torch.multiprocessing.set_sharing_strategy('file_system')
import multiprocessing as mp
import copy

config_path = './DATA_devkit/h5py_config.py'
save_path = '/home/f523/guazai/sda/rsy/graduate/dataset/COCO/h5py_car'
cat =[{'id':0, 'name':'car'},
      {'id':1, 'name':'airplane'},
      {'id':2, 'name':'ship'},
      {'id':3, 'name':'train'} ]

def h5py_create(img_data, save_path):
    f = h5py.File(save_path, 'w')
    for key, value in img_data.items():
        group = f.create_group(key)
        for i, bi_img in enumerate(value):
            group.create_dataset('img{}'.format(i), data=bi_img)
    f.close()


def extract_img(batch, keys=['cur_img', 'prev_img1', 'prev_img2']):
    datas = dict()
    for key in keys:
        img_temp = []
        for filepath in batch[key]:
            if not filepath: img_temp.append(np.asarray([]))
            else:
                with open(filepath, 'rb') as img_f:
                    bi_data = img_f.read()
                    img_temp.append(np.asarray(bi_data))
        datas[key] = img_temp
    return datas

if __name__ == '__main__':
    cfg = Config.fromfile(config_path)
    cfg.seed = 2333
    pool = mp.Pool(4)
    dataset = build_dataset(cfg.data.train)


    h5save_path = os.path.join(save_path, 'train_h5py')
    if not os.path.exists(h5save_path): os.mkdir(h5save_path)
    json_dict = {
        'images': [],
        'annotations': [],
        'categories': cat
    }
    ins_id = 0
    img_id = 0
    for id, batch in tqdm(enumerate(dataset)):
        image_tmp = dict()
        img_info = batch['img_info']
        ## 1. image info record
        image_tmp['file_name'] = img_info['filename'].split('.')[0] + '.hdf5'
        image_tmp['height'] = img_info['height']
        image_tmp['width'] = img_info['width']
        image_tmp['id'] = img_id
        json_dict['images'].append(image_tmp)
        img_id += 1
        ## 2. ann infor record
        bboxes = batch['gt_bboxes']
        for o in bboxes:
            label_tmp = dict()
            lx, ly, rx, ry = map(int, o.tolist())
            w, h = rx-lx, ry-ly
            area = w * h
            label_tmp['iscrowd'] = 0
            label_tmp['category_id'] = 0
            label_tmp['area'] = area
            label_tmp['bbox'] = (lx, ly, w, h)
            label_tmp['image_id'] = img_id
            label_tmp['id'] = ins_id
            label_tmp['segmentation'] = ()
            ins_id += 1
            json_dict['annotations'].append(label_tmp)
        ## 3. h5py record
        img_data = extract_img(batch)
        h5py_path = os.path.join(h5save_path, img_info['filename'].split('.')[0] + '.hdf5')
        #h5py_create(img_data, h5py_path)
        #pool.apply_async(h5py_create, args=[img_data, h5py_path])

    pool.close()
    pool.join()
    with open(os.path.join(save_path, 'train.json'), 'w') as f:
        json.dump(json_dict, f)


