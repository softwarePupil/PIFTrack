import os
from collections import defaultdict
import cv2
from tqdm import tqdm
import pdb
import random
random.seed(22)
import json
import  numpy as np
'''
1.data_path:
|--class
    |-- index(different video)
        |--gt
            |--gt.txt 原点在左上角
            |--gt_centorid.txt 原点在中心  
        |--img
            |--000001.jpg
            |--000002.jpg
    ...
2. save_path (like data_path, but every frame will generate an individual txt) 
|--class
    |---1(index:dir)
      |---000001.txt
      |---000002.txt
    |---2
      |---000001.txt
    ... 
'''

cls_list = ['car', 'airplane', 'ship', 'train']
cat =[{'id':0, 'name':'car'},
      {'id':1, 'name':'airplane'},
      {'id':2, 'name':'ship'},
      {'id':3, 'name':'train'} ]

cls_dict = {
    'car':0,
    'airplane':1,
    'plane':1,
    'ship':2,
    'train':3
}


def genv2(src, dst, video_list, json_name, data, img_prefix='img1', label_prefix='gt'):
    ins_id = 0
    img_id = 0
    if not os.path.exists(dst):
        os.makedirs(dst)
    print('Prcessing: [mode:{}]'.format(json_name))
    for video_index in tqdm(sorted(video_list)):
        video_path = os.path.join(src, video_index)
        label_path = os.path.join(video_path, '{}.txt'.format(label_prefix))
        # every frame id is saved in differnt keys in a video
        with open(label_path, 'r') as f:
            objs_ = [line.strip() for line in f.readlines()]
            objs = defaultdict(list)


            for j in range(len(objs_)):
                if not objs_[j]: continue
                # using VISO mode

                if ' ' in objs_[j]: raise ValueError(' there is a space in obj')
                #obj = list(map(int, objs_[j].split(',')))[:9]
                obj = [objs_[j].split(',')[0]] + list(map(int, objs_[j].split(',')[1:9]))
                frame_id = str(obj[0])
                if not '_' in frame_id: frame_id = '0' * (6 - len(frame_id)) + frame_id
                objs[frame_id].append(obj)
        if not objs:
            print('[Video idx:{}] whole video get not objs'.format(video_index))
            continue
        img_path = os.path.join(video_path, img_prefix)
        img_list = os.listdir(img_path)
        for id, filename in enumerate(sorted(img_list)):
            image_tmp = dict()

            filename = filename.split('.')[0]
            obj = objs[filename]
            if not obj:
                print('[ALERT] {} get no obj'.format(filename))
                #continue # some frame does not have label
            img = cv2.imread(os.path.join(img_path, filename + '.jpg'))
            imgh, imgw, _ = img.shape

            save_name =  video_index + '_' + filename
            image_tmp['file_name'] = save_name + '.jpg'
            image_tmp['height'] = imgh
            image_tmp['width'] = imgw
            image_tmp['id'] = img_id

            # TODO 注意一下图像的输入大小
            ### save ###
            #obj[0] = obj[0].split('_')[0]
            obj = np.array(obj, dtype=np.float32)

            _, un_index = np.unique(obj, axis=0, return_index=True)
            if len(obj) > len(un_index):
                obj = obj[un_index]
                print('{} find duplicated label, moved...'.format(filename))
            for o in obj:
                label_tmp = dict()
                lx, ly, w, h = float(o[2]), float(o[3]), float(o[4]), float(o[5])
                area = w * h
                label_tmp['iscrowd'] = 0
                label_tmp['category_id'] = int(o[7])-1
                label_tmp['area'] = area
                label_tmp['bbox'] = [lx, ly, w, h]
                label_tmp['image_id'] = img_id
                label_tmp['id'] = ins_id
                label_tmp['segmentation'] = []
                ins_id += 1
                data['annotations'].append(label_tmp)

            data['images'].append(image_tmp)
            save_img_path = os.path.join(dst, save_name + '.jpg')
            cv2.imwrite(save_img_path, img)
            img_id += 1

def genViso(src, dst, video_list, json_name, data):
    ins_id = 0
    img_id = 0
    if not os.path.exists(dst):
        os.makedirs(dst)
    print('Prcessing: [mode:{}]'.format(json_name))
    for video_index in tqdm(sorted(video_list)):
        video_path = os.path.join(src, video_index)
        label_path = os.path.join(video_path, 'gt/gt.txt')
        # every frame id is saved in differnt keys in a video
        flag = True
        with open(label_path, 'r') as f:
            objs_ = [line.strip() for line in f.readlines()]
            objs = defaultdict(list)


            for j in range(len(objs_)):
                if not objs_[j]: continue
                # using VISO mode
                if ' ' in objs_[j]:
                    obj = objs_[j].split(' ')
                else:
                    obj = objs_[j].split(',')
                    flag = False
                frame_id = obj[0]
                frame_id = '0' * (6 - len(frame_id)) + frame_id
                objs[frame_id].append(obj)
        img_path = os.path.join(video_path, 'img')
        img_list = os.listdir(img_path)
        for id, filename in enumerate(sorted(img_list)):
            image_tmp = dict()

            filename = filename.split('.')[0]
            obj = objs[filename]
            if not obj:
                print('[ALERT] {} get no obj'.format(filename))
                #continue # some frame does not have label
            img = cv2.imread(os.path.join(img_path, filename + '.jpg'))
            imgh, imgw, _ = img.shape

            save_name =  video_index + '_' + filename
            image_tmp['file_name'] = save_name + '.jpg'
            image_tmp['height'] = imgh
            image_tmp['width'] = imgw
            image_tmp['id'] = img_id

            # TODO 注意一下图像的输入大小
            ### save ###
            obj = np.array(obj, dtype=np.float32)
            _, un_index = np.unique(obj, axis=0, return_index=True)
            if len(obj) > len(un_index):
                obj = obj[un_index]
                print('{} find duplicated label, moved...'.format(filename))
            for o in obj:
                label_tmp = dict()
                if not flag:
                    lx, ly, w, h = float(o[2]), float(o[3]), float(o[4]), float(o[5])
                else:
                    lx, ly, rx, ry = float(o[2]), float(o[3]), float(o[4]), float(o[5])
                    w, h = (rx-lx), (ry-ly)
                area = w*h
                label_tmp['iscrowd'] = 0
                #pdb.set_trace()
                label_tmp['category_id'] = cls_dict[video_index.split('_')[0]]
                label_tmp['area'] = area
                label_tmp['bbox'] = [lx, ly, w, h]
                label_tmp['image_id'] = img_id
                label_tmp['id'] = ins_id
                label_tmp['segmentation'] = []
                ins_id += 1
                data['annotations'].append(label_tmp)

            data['images'].append(image_tmp)
            save_img_path = os.path.join(dst, save_name + '.jpg')
            cv2.imwrite(save_img_path, img)
            img_id += 1

def mainv2(train_dir, val_dir, save_dir, img_prefix='img1', label_prefix='gt'):
    train_video_list = os.listdir(train_dir)
    val_video_list = os.listdir(val_dir)
    train_json = {
        'images': [],
        'annotations': [],
        'categories': cat
    }
    val_json = {
        'images': [],
        'annotations': [],
        'categories': cat
    }

    genv2(train_dir, os.path.join(save_dir, 'train_images'), train_video_list, 'train',
          train_json, img_prefix, label_prefix)
    genv2(val_dir, os.path.join(save_dir, 'val_images'), val_video_list, 'val',
          val_json, img_prefix, label_prefix)
    with open(os.path.join(save_dir, 'train.json'), 'w') as f:
        json.dump(train_json, f)
    with open(os.path.join(save_dir, 'val.json'), 'w') as f:
        json.dump(val_json, f)

def mainViso(train_dir, val_dir, save_dir):
    train_video_list = os.listdir(train_dir)
    val_video_list = os.listdir(val_dir)
    train_json = {
        'images': [],
        'annotations': [],
        'categories': cat
    }
    val_json = {
        'images': [],
        'annotations': [],
        'categories': cat
    }

    genViso(train_dir, os.path.join(save_dir, 'train_images'), train_video_list, 'train', train_json)
    genViso(val_dir, os.path.join(save_dir, 'val_images'), val_video_list, 'val', val_json)
    with open(os.path.join(save_dir, 'train.json'), 'w') as f:
        json.dump(train_json, f)
    with open(os.path.join(save_dir, 'val.json'), 'w') as f:
        json.dump(val_json, f)

def main_seg(train_dir, val_dir, save_dir):
    #train_video_list = os.listdir(train_dir)
    train_seg_path = '/home/f523/guazai/disk3/rsy/dataset/ICPR_GAME_2022/seg_npy_gt'
    train_video_list = [npy_file.split('.')[0] for npy_file in os.listdir(train_seg_path)]

    val_video_list = os.listdir(val_dir)
    train_json = {
        'images': [],
        'annotations': [],
        'categories': cat
    }
    val_json = {
        'images': [],
        'annotations': [],
        'categories': cat
    }

    print('training data generating...')
    genv2(train_dir, os.path.join(save_dir, 'train_images'), train_video_list, 'train', train_json)
    print('validation data generating...')
    genv2(val_dir, os.path.join(save_dir, 'val_images'), val_video_list, 'val', val_json)
    with open(os.path.join(save_dir, 'train.json'), 'w') as f:
        json.dump(train_json, f)
    with open(os.path.join(save_dir, 'val.json'), 'w') as f:
        json.dump(val_json, f)



if __name__ == '__main__':
    ######### ICPR Game #####################
    train_data_dir = '/home/f523/guazai/disk3/rsy/dataset/ICPR_GAME_2022/seg_training_data'
    val_data_dir = '/home/f523/guazai/disk3/rsy/dataset/ICPR_GAME_2022/seg_validation_data'
    save_dir = '/home/f523/guazai/sda/rsy/graduate/dataset/COCO/car'
    if not os.path.exists(save_dir):
       os.makedirs(save_dir)
    mainv2(train_data_dir, val_data_dir, save_dir)
    # main_seg(train_data_dir, val_data_dir, save_dir)
    # mainViso(train_data_dir, val_data_dir, save_dir)

