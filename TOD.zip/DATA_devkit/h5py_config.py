temporal_frame = 3
sample_num = 2
group_num = 3
mem_size = 3

# dataset settings
dataset_type = 'CocoRemote_Car_ordered'
data_root = '/home/f523/guazai/sda/rsy/graduate/dataset/COCO/car/'
img_norm_cfg = dict(
    mean=[103.38, 105.66, 105.79], std=[44.978, 42.367, 39.412], to_rgb=True)

totensor = ['img']
keys = ['img', 'gt_bboxes', 'gt_labels']
id = 'prev_img{}'
for i in range(sample_num):
    keys.append(id.format(i+1))
    totensor.append(id.format(i+1))

train_pipeline = [
    dict(type='LoadTemporalImageMemInfo', temporal_frame=temporal_frame, sample_num=sample_num, group_num=group_num),
]



train_dataset = dict(
    type='TemporalImageSeqDataset',
    dataset=dict(
        type='CocoRemote_Car_ordered',
        ann_file=data_root + 'train.json',
        img_prefix=data_root + 'train_images/',
        pipeline=[
            dict(type='LoadImageFromFile'),
            dict(type='LoadAnnotations', with_bbox=True)
        ],
        filter_empty_gt=False,
    ),
    pipeline=train_pipeline)



# TODO r18 per_gpu = 2, r50 is 1
data = dict(
    samples_per_gpu=1,
    workers_per_gpu=0,
    persistent_workers=False,
    train=train_dataset,
)