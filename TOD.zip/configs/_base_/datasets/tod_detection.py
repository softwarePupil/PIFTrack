temporal_frame = 2
frame_inte = 0

# dataset settings
dataset_type = 'CocoRemote_Car_ordered'
data_root = '/home/f523/guazai/sda/rsy/graduate/dataset/COCO/car/'
img_norm_cfg = dict(
    mean=[103.38, 105.66, 105.79], std=[44.978, 42.367, 39.412], to_rgb=True)
train_pipeline = [
    dict(type='LoadTemporalImage', temporal_frame=temporal_frame, frame_inte=frame_inte),
    dict(type='Resize', img_scale=(1024, 1024), keep_ratio=True),
    dict(type='RandomFlip', flip_ratio=0.5),
    dict(type='Normalize', **img_norm_cfg),
    dict(type='Pad', size_divisor=32),
    dict(type='DefaultFormatBundle'),
    dict(type='Collect', keys=['img', 'gt_bboxes', 'gt_labels']),
]

test_pipeline = [
    dict(type='LoadTemporalImage', temporal_frame=temporal_frame, frame_inte=frame_inte),
    dict(
        type='MultiScaleFlipAug',
        img_scale=(1024, 1024),
        flip=False,
        transforms=[
            dict(type='Resize', keep_ratio=True),
            dict(type='RandomFlip'),
            dict(type='Normalize', **img_norm_cfg),
            dict(type='Pad', size_divisor=32),
            dict(type='ImageToTensor', keys=['img']),
            dict(type='Collect', keys=['img']),
        ])
]

train_dataset = dict(
    type='TemporalImageSeqDataset',
    dataset=dict(
        type=dataset_type,
        ann_file=data_root + 'train.json',
        img_prefix=data_root + 'train_images/',
        pipeline=[
            dict(type='LoadImageFromFile'),
            dict(type='LoadAnnotations', with_bbox=True)
        ],
        filter_empty_gt=False,
    ),
    pipeline=train_pipeline)

test_dataset = dict(
    type='TemporalImageSeqDataset',
    dataset=dict(
        type=dataset_type,
        ann_file=data_root + 'val.json',
        img_prefix=data_root + 'val_images/',
        pipeline=[
            dict(type='LoadImageFromFile'),
        ],
    ),
    pipeline=test_pipeline
)
data = dict(
    samples_per_gpu=2,
    workers_per_gpu=8,
    persistent_workers=True,
    train=train_dataset,
    val=test_dataset,
    test=test_dataset)