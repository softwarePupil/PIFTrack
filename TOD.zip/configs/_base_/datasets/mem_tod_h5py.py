temporal_frame = 3
sample_num = 2
group_num = 3
mem_size = 3

# dataset settings
dataset_type = 'CocoRemote_Car_ordered'
data_root = '/home/f523/guazai/sda/rsy/graduate/dataset/COCO/car/'
h5py_root = '/home/f523/guazai/sda/rsy/graduate/dataset/COCO/h5py_car/'
img_norm_cfg = dict(
    mean=[103.38, 105.66, 105.79], std=[44.978, 42.367, 39.412], to_rgb=True)

totensor = ['img']
keys = ['img', 'gt_bboxes', 'gt_labels']
id = 'prev_img{}'
for i in range(sample_num):
    keys.append(id.format(i+1))
    totensor.append(id.format(i+1))

test_pipeline = [
    dict(type='LoadTemporalImage', temporal_frame=sample_num, return_diff=False),
    dict(
        type='MultiScaleFlipAug',
        img_scale=(1024, 1024),
        flip=False,
        transforms=[
            dict(type='Resize', keep_ratio=True),
            dict(type='RandomFlip'),
            dict(type='Normalize', **img_norm_cfg),
            dict(type='Pad', size_divisor=32),
            dict(type='ImageToTensor', keys=['img']),
            dict(type='Collect', keys=['img']),
        ])
]

train_dataset = dict(
        type='CocoRemote_Car_ordered',
        ann_file=h5py_root + 'train.json',
        img_prefix=h5py_root + 'train_h5py/',
        pipeline=[
            dict(type='LoadImageFromH5py'),
            dict(type='LoadAnnotations', with_bbox=True),
            dict(type='Resize', img_scale=(1024, 1024), keep_ratio=True),
            dict(type='RandomFlip', flip_ratio=0.5),
            dict(type='Normalize', **img_norm_cfg),
            dict(type='Pad', size_divisor=32),
            dict(type='DefaultFormatBundle', keys=totensor),
            dict(type='Collect', keys=keys),
        ],
        filter_empty_gt=False,
    )

test_dataset = dict(
    type='TemporalImageSeqDataset',
    dataset=dict(
        type='CocoRemote_Car_ordered',
        ann_file=data_root + 'val.json',
        img_prefix=data_root + 'val_images/',
        pipeline=[
            dict(type='LoadImageFromFile'),
        ],
    ),
    pipeline=test_pipeline
)

# TODO r18 per_gpu = 2, r50 is 1
data = dict(
    samples_per_gpu=1,
    workers_per_gpu=8,
    persistent_workers=True,
    train=train_dataset,
    val=test_dataset,
    test=test_dataset)