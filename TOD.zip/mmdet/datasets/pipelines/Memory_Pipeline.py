import pdb

from ..builder import PIPELINES
import numpy as np
import os.path as osp
import mmcv
import os

@PIPELINES.register_module()
class LoadTemporalImageMem:
    """Load an image from file.

    Required keys are "img_prefix" and "img_info" (a dict that must contain the
    key "filename"). Added or updated keys are "filename", "img", "img_shape",
    "ori_shape" (same as `img_shape`), "pad_shape" (same as `img_shape`),
    "scale_factor" (1.0) and "img_norm_cfg" (means=0 and stds=1).

    Args:
        to_float32 (bool): Whether to convert the loaded image to a float32
            numpy array. If set to False, the loaded image is an uint8 array.
            Defaults to False.
        color_type (str): The flag argument for :func:`mmcv.imfrombytes`.
            Defaults to 'color'.
        file_client_args (dict): Arguments to instantiate a FileClient.
            See :class:`mmcv.fileio.FileClient` for details.
            Defaults to ``dict(backend='disk')``.
    """

    def __init__(self,
                 temporal_frame=10,
                 sample_num=3,
                 group_num=1,
                 to_float32=False,
                 color_type='color',
                 file_client_args=dict(backend='disk')):
        self.to_float32 = to_float32
        self.color_type = color_type
        self.file_client_args = file_client_args.copy()
        self.file_client = None
        self.temporal_frame=temporal_frame
        self.sample_num = sample_num
        self.group_num = group_num

    def get_temporal_indexes(self, dataset, results):
        # 看看results是什么，返回的是temporal的索引，如果不存在则是-1
        group_num = self.group_num - 1

        filename = results['ori_filename']
        #Note I using split data
        # If use whole data, the data format may be different
        #pdb.set_trace()
        img_format = filename.split('.')[1]
        filename = filename.split('.')[0].split('_')
        frame_id = int(filename[-1])
        temporal_info = []
        start_id = max(1, frame_id-self.temporal_frame)
        end_idx = max(self.sample_num+1, frame_id)
        chose_ids = np.random.choice([i for i in range(start_id, end_idx)], self.sample_num, replace=False)

        for start_i in chose_ids:
            temp_info = []
            for i in range(start_i-group_num, start_i+1):
                if i<=0:
                    temp_info.append(dict())
                else:
                    cur_frame_id = '0'*(6-len(str(i)))+str(i)
                    cur_filename = filename.copy()
                    cur_filename[-1] = cur_frame_id
                    cur_filename = '_'.join(cur_filename)+'.{}'.format(img_format)
                    cur_id = dataset.coco.get_img_ids(img_ids=[], cat_ids=[], filename=cur_filename)
                    img = dataset.coco.load_imgs(cur_id)
                    temp_info.extend(img)

            temporal_info.append(temp_info)

        temp_info = []
        for i in range(frame_id-group_num, frame_id):
            if i <= 0:
                temp_info.append(dict())
            else:
                cur_frame_id = '0' * (6 - len(str(i))) + str(i)
                cur_filename = filename.copy()
                cur_filename[-1] = cur_frame_id
                cur_filename = '_'.join(cur_filename) + '.{}'.format(img_format)
                cur_id = dataset.coco.get_img_ids(img_ids=[], cat_ids=[], filename=cur_filename)
                img = dataset.coco.load_imgs(cur_id)
                temp_info.extend(img)
        temporal_info.append(temp_info)

        return temporal_info, self.temporal_frame



    def __call__(self, results):
        """Call functions to load image and get image meta information.

        Args:
            results (dict): Result dict from :obj:`mmdet.CustomDataset`.

        Returns:
            dict: The dict contains loaded image and meta information.
        """

        if self.file_client is None:
            self.file_client = mmcv.FileClient(**self.file_client_args)

        imgs = []
        h, w = results['img'].shape[:2]

        for temp_infos in results['temporal_img_info'][:-1]:
            if not temp_infos:
                raise ValueError('temp info is None')
            else:
                temp_img = []
                for temp_info in temp_infos:
                    if not temp_info:
                        temp_img.append(np.zeros_like(results['img']))
                        continue
                    if results['img_prefix'] is not None:
                        filename = osp.join(results['img_prefix'],
                                            temp_info['file_name'])
                    else:
                        filename = temp_info['file_name']

                    img_bytes = self.file_client.get(filename)
                    img = mmcv.imfrombytes(img_bytes, flag=self.color_type)
                    if self.to_float32:
                        img = img.astype(np.float32)
                    hn, wn = img.shape[:2]
                    h, w = min(h,hn), min(w, wn)
                    temp_img.append(img[:h, :w])
                imgs.append(np.concatenate(temp_img, axis=-1))

        temp_img = []
        for temp_info in results['temporal_img_info'][-1]:
            if not temp_info:
                temp_img.append(np.zeros_like(results['img']))
                continue
            if results['img_prefix'] is not None:
                filename = osp.join(results['img_prefix'],
                                    temp_info['file_name'])
            else:
                filename = temp_info['file_name']

            img_bytes = self.file_client.get(filename)
            img = mmcv.imfrombytes(img_bytes, flag=self.color_type)
            if self.to_float32:
                img = img.astype(np.float32)
            hn, wn = img.shape[:2]
            h, w = min(h, hn), min(w, wn)
            temp_img.append(img[:h, :w])
        temp_img.append(results['img'])

        # pdb.set_trace()
        results['img'] = np.concatenate(temp_img, axis=-1)

        prev_id = 'prev_img{}'
        img_fields = ['img']
        for i in range(len(imgs)):
            imgs[i] = imgs[i][:h, :w]
            results[prev_id.format(i+1)] = imgs[i]
            img_fields.append(prev_id.format(i+1))
        results['img_fields'] = img_fields
        return results

    def __repr__(self):
        repr_str = (f'{self.__class__.__name__}('
                    f'to_float32={self.to_float32}, '
                    f"color_type='{self.color_type}', "
                    f'file_client_args={self.file_client_args})')
        return repr_str


@PIPELINES.register_module()
class LoadTemporalImageMemInfo:
    def __init__(self,
                 temporal_frame=10,
                 sample_num=3,
                 group_num=1,
                 to_float32=False,
                 color_type='color',
                 file_client_args=dict(backend='disk')):
        self.to_float32 = to_float32
        self.color_type = color_type
        self.file_client_args = file_client_args.copy()
        self.file_client = None
        self.temporal_frame = temporal_frame
        self.sample_num = sample_num
        self.group_num = group_num

    def get_temporal_indexes(self, dataset, results):
        # 看看results是什么，返回的是temporal的索引，如果不存在则是-1
        group_num = self.group_num - 1

        filename = results['ori_filename']
        # Note I using split data
        # If use whole data, the data format may be different
        # pdb.set_trace()
        img_format = filename.split('.')[1]
        filename = filename.split('.')[0].split('_')
        frame_id = int(filename[-1])
        temporal_info = []
        start_id = max(1, frame_id - self.temporal_frame)
        end_idx = max(self.sample_num + 1, frame_id) # 取 max是保证每次采样两张，初始化存在一定问题，但整体影响不大
        chose_ids = np.random.choice([i for i in range(start_id, end_idx)], self.sample_num, replace=False)
        for start_i in chose_ids:
            temp_info = []
            for i in range(start_i - group_num, start_i + 1):
                if i <= 0:
                    temp_info.append(dict())
                else:
                    cur_frame_id = '0' * (6 - len(str(i))) + str(i)
                    cur_filename = filename.copy()
                    cur_filename[-1] = cur_frame_id
                    cur_filename = '_'.join(cur_filename) + '.{}'.format(img_format)
                    cur_id = dataset.coco.get_img_ids(img_ids=[], cat_ids=[], filename=cur_filename)
                    img = dataset.coco.load_imgs(cur_id)
                    temp_info.extend(img)

            temporal_info.append(temp_info)

        temp_info = []
        for i in range(frame_id - group_num, frame_id):
            if i <= 0:
                temp_info.append(dict())
            else:
                cur_frame_id = '0' * (6 - len(str(i))) + str(i)
                cur_filename = filename.copy()
                cur_filename[-1] = cur_frame_id
                cur_filename = '_'.join(cur_filename) + '.{}'.format(img_format)
                cur_id = dataset.coco.get_img_ids(img_ids=[], cat_ids=[], filename=cur_filename)
                img = dataset.coco.load_imgs(cur_id)
                temp_info.extend(img)
        temporal_info.append(temp_info)

        return temporal_info, self.temporal_frame

    def __call__(self, results):
        """Call functions to load image and get image meta information.

        Args:
            results (dict): Result dict from :obj:`mmdet.CustomDataset`.

        Returns:
            dict: The dict contains loaded image and meta information.
        """

        if self.file_client is None:
            self.file_client = mmcv.FileClient(**self.file_client_args)

        imgs = []
        h, w = results['img'].shape[:2]
        for temp_infos in results['temporal_img_info'][:-1]:
            if not temp_infos:
                raise ValueError('temp info is None')
            else:
                temp_img = []
                for temp_info in temp_infos:
                    if not temp_info:
                        temp_img.append('')
                        continue
                    if results['img_prefix'] is not None:
                        filename = osp.join(results['img_prefix'],
                                            temp_info['file_name'])
                    else:
                        filename = temp_info['file_name']
                    temp_img.append(filename)

                imgs.append(temp_img)

        temp_img = []
        for temp_info in results['temporal_img_info'][-1]:
            if not temp_info:
                temp_img.append('')
                continue
            if results['img_prefix'] is not None:
                filename = osp.join(results['img_prefix'],
                                    temp_info['file_name'])
            else:
                filename = temp_info['file_name']
            temp_img.append(filename)
        temp_img.append(os.path.join(results['img_prefix'], results['img_info']['file_name']))

        prev_id = 'prev_img{}'
        for i in range(len(imgs)):
            results[prev_id.format(i + 1)] = imgs[i]
        results['cur_img'] = temp_img
        return results

    def __repr__(self):
        repr_str = (f'{self.__class__.__name__}('
                    f'to_float32={self.to_float32}, '
                    f"color_type='{self.color_type}', "
                    f'file_client_args={self.file_client_args})')
        return repr_str

