from .resnet import ResNet
from ..builder import BACKBONES
from torch import nn
import torch
import pdb

def sigmoid_k(x, offset, k=3):
    if offset.numel() == 1:
        # offset is a scale
        return 1/(1+torch.exp(-k*(x-offset)))
    else:
        # offset shape is equal to x
        assert offset.shape[2:] == x.shape[2:]
        offset = torch.repeat_interleave(offset, x.shape[1], dim=1)
        return 1 / (1 + torch.exp(-k * (x - offset)))

@BACKBONES.register_module()
class Diff_ResNet(ResNet):
    def __init__(self,
                 alpha,
                 *args,
                 **kwargs):
        super(Diff_ResNet, self).__init__(*args, **kwargs)
        # self.offset = nn.Parameter(data=torch.tensor(0.), requires_grad=True) # 因为是可学习，如果开了不求梯度会报错
        self.alpha = alpha

    def forward_single(self, x):
        if self.deep_stem:
            x = self.stem(x)
        else:
            x = self.conv1(x)
            x = self.norm1(x)
            x = self.relu(x)
        x = self.maxpool(x)
        outs = []
        for i, layer_name in enumerate(self.res_layers):
            res_layer = getattr(self, layer_name)
            x = res_layer(x)
            if i in self.out_indices:
                outs.append(x)
        return tuple(outs)

    def diff_calculate(self, curs, prevs):
        return tuple([curs[i]-prevs[i] for i in range(len(curs))])

    def backES_calculate(self, diffs, curs):
        outs = []
        for i in range(len(diffs)):
            diff = sigmoid_k(diffs[i].abs(), self.offset)
            new = diff * curs[i] * self.alpha + curs[i] * (1-self.alpha)
            outs.append(new)
        return tuple(outs)

    def forward(self, x):
        """Forward function."""
        x_prev = x[:,:3]
        x_cur = x[:,3:]
        xprev_outs = self.forward_single(x_prev)
        xcur_outs = self.forward_single(x_cur)
        x_diffs = self.diff_calculate(xcur_outs, xprev_outs)
        return x_diffs
        outs = self.backES_calculate(x_diffs, xcur_outs)
        return outs


