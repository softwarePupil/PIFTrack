# Copyright (c) OpenMMLab. All rights reserved.
import warnings

import torch
import pdb

from ..builder import DETECTORS, build_backbone, build_head, build_neck, build_loss
from .base import BaseDetector
from torch.nn.modules.utils import _pair
from mmdet.core import build_prior_generator
import numpy as np
import time
from torchvision.transforms import functional as TF
import torch.nn.functional as F
import cv2
import os
import shutil

# TODO 学习如何产生相应的anchor
@DETECTORS.register_module()
class roadAnchorDet(BaseDetector):
    """Base class for two-stage detectors.

    Two-stage detectors typically consisting of a region proposal network and a
    task-specific regression head.
    """

    def __init__(self,
                 backbone,
                 neck=None,
                 roi_head=None,
                 anchor_cfg=None,
                 train_cfg=None,
                 test_cfg=None,
                 pretrained=None,
                 init_cfg=None,
                 loss_seg=None,
                ):
        super(roadAnchorDet, self).__init__(init_cfg)
        if pretrained:
            warnings.warn('DeprecationWarning: pretrained is deprecated, '
                          'please use "init_cfg" instead')
            backbone.pretrained = pretrained

        self.backbone = build_backbone(backbone)

        if neck is not None:
            self.neck = build_neck(neck)



        if roi_head is not None:
            # update train and test cfg here for now
            # TODO: refactor assigner & sampler
            rcnn_train_cfg = train_cfg.rcnn if train_cfg is not None else None
            roi_head.update(train_cfg=rcnn_train_cfg)
            roi_head.update(test_cfg=test_cfg.rcnn)
            roi_head.pretrained = pretrained
            self.roi_head = build_head(roi_head)

        # road anchor工程上的实现，先用anchor generator 实现全图的密集排布，再利用分割结果把不需要的排除
        self.anchor_cfg = anchor_cfg
        self.train_cfg = train_cfg
        self.test_cfg = test_cfg
        self.prior_generator = build_prior_generator(anchor_cfg.anchor_generator)

        self.loss_seg = build_loss(loss_seg)
        self.iter = 1

    @property
    def with_roi_head(self):
        """bool: whether the detector has a RoI head"""
        return hasattr(self, 'roi_head') and self.roi_head is not None

    def extract_feat(self, img):
        """Directly extract features from the backbone+neck."""
        x = self.backbone(img)
        if self.with_neck:
            x = self.neck(x)
        return x

    def forward_dummy(self, img):
        """Used for computing network flops.

        See `mmdetection/tools/analysis_tools/get_flops.py`
        """
        outs = ()
        # backbone
        x = self.extract_feat(img)

        proposals = torch.randn(1000, 4).to(img.device)
        # roi_head
        roi_outs = self.roi_head.forward_dummy(x, proposals)
        outs = outs + (roi_outs, )
        return outs



    def forward_train(self,
                      img,
                      img_metas,
                      gt_bboxes,
                      gt_labels,
                      gt_bboxes_ignore=None,
                      gt_masks=None,
                      proposals=None,
                      **kwargs):
        #pdb.set_trace()
        outs = self.extract_feat(img)

        x, seg = outs[0], outs[1]
        seg_map = seg.argmax(dim=1).detach().unsqueeze(1).float()
        device = x.device
        #featmap_sizes = x.shape[2:]

        # self.iter += 1
        # if self.iter % 1 == 0:
        #     # pdb.set_trace()
        #     file_path = img_metas[0]['filename']
        #     file_name = img_metas[0]['ori_filename']
        #     seg_cpu = seg_map.cpu().numpy()
        #     seg_cpu = seg_cpu[0, 0]
        #     save_path = '/home/f523/guazai/disk3/rsy/code/mmgame/seg_vis_map'
        #     shutil.copy(file_path, os.path.join(save_path, file_name.split('.')[0] + '_iter' + str(self.iter) + '.png'))
        #     cv2.imwrite(os.path.join(save_path, file_name.split('.')[0] + '_map_iter' + str(self.iter) + '.png'), \
        #                 (seg_cpu * 255).astype('uint8'))

        # TODO proposal list似乎要带上batch idx?
        proposal_list = self.prior_generator.get_sparse_proposal(seg_map, device)

        

        losses = dict()


        # TODO 外部加入的proposal_list 如何处理
        #proposal_list = proposals

        if not proposal_list: return losses

        # TODO proposal list 来自于road seg

        roi_losses = self.roi_head.forward_train([x], img_metas, proposal_list,
                                                 gt_bboxes, gt_labels,
                                                 gt_bboxes_ignore, gt_masks,
                                                 **kwargs)

        # loss of segmentation
        gt_road_seg = kwargs['gt_road_seg']
        if self.loss_seg.use_sigmoid:
            batch, c, h, w = seg.shape
            seg_scores = seg.reshape(-1)
        else:
            batch, c, h, w = seg.shape
            seg_scores = seg.permute(0, 2, 3, 1).reshape(-1, c)
        gt_road_seg = TF.resize(gt_road_seg, (h, w))
        gt_road_seg = gt_road_seg.reshape(-1)
        #pdb.set_trace()
        # pdb.set_trace()
        if not (gt_road_seg.min().item() >= 0 and gt_road_seg.max().item() <= 1):
            pdb.set_trace()
        seg_losses = {'loss_seg':self.loss_seg(seg_scores, gt_road_seg.type(torch.int64))}

        #pdb.set_trace()
        losses.update(roi_losses)
        losses.update(seg_losses)

        del seg_map
        return losses

    async def async_simple_test(self,
                                img,
                                img_meta,
                                proposals=None,
                                rescale=False):
        """Async test without augmentation."""
        assert self.with_bbox, 'Bbox head must be implemented.'
        x = self.extract_feat(img)

        if proposals is None:
            proposal_list = await self.rpn_head.async_simple_test_rpn(
                x, img_meta)
        else:
            proposal_list = proposals

        return await self.roi_head.async_simple_test(
            x, proposal_list, img_meta, rescale=rescale)

    # TODO 这边都要进行更改
    def simple_test(self, img, img_metas, proposals=None, rescale=False):
        """Test without augmentation."""

        assert self.with_bbox, 'Bbox head must be implemented.'
        outs = self.extract_feat(img)
        x, seg = outs[0], outs[-1]
        seg_map = seg.argmax(dim=1).detach().unsqueeze(1).float()
        device = x.device
        if proposals is None:
            proposal_list = self.prior_generator.get_sparse_proposal(seg_map, device)
        else:
            proposal_list = proposals

        return self.roi_head.simple_test(
            [x], proposal_list, img_metas, rescale=rescale)

    def aug_test(self, imgs, img_metas, rescale=False):
        """Test with augmentations.

        If rescale is False, then returned bboxes and masks will fit the scale
        of imgs[0].
        """
        x = self.extract_feats(imgs)
        proposal_list = self.rpn_head.aug_test_rpn(x, img_metas)
        return self.roi_head.aug_test(
            x, proposal_list, img_metas, rescale=rescale)

    def onnx_export(self, img, img_metas):

        img_shape = torch._shape_as_tensor(img)[2:]
        img_metas[0]['img_shape_for_onnx'] = img_shape
        x = self.extract_feat(img)
        proposals = self.rpn_head.onnx_export(x, img_metas)
        if hasattr(self.roi_head, 'onnx_export'):
            return self.roi_head.onnx_export(x, proposals, img_metas)
        else:
            raise NotImplementedError(
                f'{self.__class__.__name__} can not '
                f'be exported to ONNX. Please refer to the '
                f'list of supported models,'
                f'https://mmdetection.readthedocs.io/en/latest/tutorials/pytorch2onnx.html#list-of-supported-models-exportable-to-onnx'  # noqa E501
            )


@DETECTORS.register_module()
class roadAnchorDetHeat(BaseDetector):
    """Base class for two-stage detectors.

    Two-stage detectors typically consisting of a region proposal network and a
    task-specific regression head.
    """

    def __init__(self,
                 backbone,
                 neck=None,
                 map_head=None,
                 roi_head=None,
                 anchor_cfg=None,
                 train_cfg=None,
                 test_cfg=None,
                 pretrained=None,
                 init_cfg=None,
                 ):
        super(roadAnchorDetHeat, self).__init__(init_cfg)
        if pretrained:
            warnings.warn('DeprecationWarning: pretrained is deprecated, '
                          'please use "init_cfg" instead')
            backbone.pretrained = pretrained

        self.backbone = build_backbone(backbone)

        if neck is not None:
            self.neck = build_neck(neck)

        if roi_head is not None:
            # update train and test cfg here for now
            # TODO: refactor assigner & sampler
            rcnn_train_cfg = train_cfg.rcnn if train_cfg is not None else None
            roi_head.update(train_cfg=rcnn_train_cfg)
            roi_head.update(test_cfg=test_cfg.rcnn)
            roi_head.pretrained = pretrained
            self.roi_head = build_head(roi_head)

        # road anchor工程上的实现，先用anchor generator 实现全图的密集排布，再利用分割结果把不需要的排除
        self.anchor_cfg = anchor_cfg
        self.train_cfg = train_cfg
        self.test_cfg = test_cfg
        self.prior_generator = build_prior_generator(anchor_cfg.anchor_generator)
        self.map_head = build_head(map_head)
        self.iter = 0

    @property
    def with_roi_head(self):
        """bool: whether the detector has a RoI head"""
        return hasattr(self, 'roi_head') and self.roi_head is not None

    def extract_feat(self, img):
        """Directly extract features from the backbone+neck."""
        x = self.backbone(img)
        if self.with_neck:
            x = self.neck(x)
        return x

    def forward_dummy(self, img):
        """Used for computing network flops.

        See `mmdetection/tools/analysis_tools/get_flops.py`
        """
        outs = ()
        # backbone
        x = self.extract_feat(img)

        proposals = torch.randn(1000, 4).to(img.device)
        # roi_head
        roi_outs = self.roi_head.forward_dummy(x, proposals)
        outs = outs + (roi_outs,)
        return outs

    def forward_train(self,
                      img,
                      img_metas,
                      gt_bboxes,
                      gt_labels,
                      gt_bboxes_ignore=None,
                      gt_masks=None,
                      proposals=None,
                      **kwargs):
        # pdb.set_trace()
        x = self.extract_feat(img)

        gt_road_seg = kwargs['gt_road_seg']
        map_outs, map_losses = self.map_head.forward_train(x, img_metas, \
                                                           gt_bboxes, gt_road_seg, gt_labels, gt_bboxes_ignore)
        #pdb.set_trace()
        center_preds, road_preds = map_outs
        center_pred, road_pred = center_preds[0], road_preds[0]
        road_map = road_pred.argmax(dim=1).unsqueeze(1).float()
        #center_map = self.get_local_maximum(center_pred)
        #pdb.set_trace()
        road_map = road_map > 0
        center_map = center_pred > 0.6
        Map = torch.logical_or(road_map, center_map)
        Map = Map.detach()
        device = x[0].device

        ##### visulization debug ##
        # if self.iter % 100 == 0:
        #     # pdb.set_trace()
        #     file_path = img_metas[0]['filename']
        #     file_name = img_metas[0]['ori_filename']
        #     road_cpu = road_map.cpu().numpy();
        #     road_cpu = road_cpu[0, 0]
        #     center_cpu = center_map.cpu().numpy();
        #     center_cpu = center_cpu[0, 0]
        #     map_cpu = Map.cpu().numpy();
        #     map_cpu = map_cpu[0, 0]
        #     save_path = '/home/f523/guazai/disk3/rsy/code/mmgame/seg_vis_map'
        #     shutil.copy(file_path,
        #                 os.path.join(save_path, 'iter{}_'.format(str(self.iter)) + file_name.split('.')[0] + '.png'))
        #     cv2.imwrite(os.path.join(save_path,
        #                              'iter{}_'.format(str(self.iter)) + file_name.split('.')[0] + '_roadMap' + '.png'), \
        #                 (road_cpu * 255).astype('uint8'))
        #     cv2.imwrite(os.path.join(save_path, 'iter{}_'.format(str(self.iter)) + file_name.split('.')[
        #         0] + '_centerMap' + '.png'), \
        #                 (center_cpu * 255).astype('uint8'))
        #     cv2.imwrite(os.path.join(save_path,
        #                              'iter{}_'.format(str(self.iter)) + file_name.split('.')[0] + '_totalMap' + '.png'), \
        #                 (map_cpu * 255).astype('uint8'))
        # self.iter += 1
        ################
        #return map_losses


        proposal_list = self.prior_generator.get_sparse_proposal(Map, device)

        losses = dict()

        # TODO 外部加入的proposal_list 如何处理
        # proposal_list = proposals

        if not proposal_list: return losses

        roi_losses = self.roi_head.forward_train(x, img_metas, proposal_list,
                                                 gt_bboxes, gt_labels,
                                                 gt_bboxes_ignore, gt_masks,
                                                 **kwargs)


        # pdb.set_trace()
        losses.update(roi_losses)
        losses.update(map_losses)

        return losses

    async def async_simple_test(self,
                                img,
                                img_meta,
                                proposals=None,
                                rescale=False):
        """Async test without augmentation."""
        assert self.with_bbox, 'Bbox head must be implemented.'
        x = self.extract_feat(img)

        if proposals is None:
            proposal_list = await self.rpn_head.async_simple_test_rpn(
                x, img_meta)
        else:
            proposal_list = proposals

        return await self.roi_head.async_simple_test(
            x, proposal_list, img_meta, rescale=rescale)

    # TODO 这边都要进行更改
    def simple_test(self, img, img_metas, proposals=None, rescale=False):
        """Test without augmentation."""

        assert self.with_bbox, 'Bbox head must be implemented.'
        x = self.extract_feat(img)
        map_outs = self.map_head.forward(x)
        center_preds, road_preds = map_outs
        center_pred, road_pred = center_preds[0], road_preds[0]
        road_map = road_pred.argmax(dim=1).unsqueeze(1).float()
        #center_map = self.get_local_maximum(center_pred)
        center_map = center_pred > 0.6
        Map = torch.logical_or(road_map, center_map)
        Map = Map.detach()
        device = x[0].device


        if proposals is None:
            proposal_list = self.prior_generator.get_sparse_proposal(Map, device)
        else:
            proposal_list = proposals

        return self.roi_head.simple_test(
            x, proposal_list, img_metas, rescale=rescale)

    def aug_test(self, imgs, img_metas, rescale=False):
        """Test with augmentations.

        If rescale is False, then returned bboxes and masks will fit the scale
        of imgs[0].
        """
        x = self.extract_feats(imgs)
        proposal_list = self.rpn_head.aug_test_rpn(x, img_metas)
        return self.roi_head.aug_test(
            x, proposal_list, img_metas, rescale=rescale)

    def onnx_export(self, img, img_metas):

        img_shape = torch._shape_as_tensor(img)[2:]
        img_metas[0]['img_shape_for_onnx'] = img_shape
        x = self.extract_feat(img)
        proposals = self.rpn_head.onnx_export(x, img_metas)
        if hasattr(self.roi_head, 'onnx_export'):
            return self.roi_head.onnx_export(x, proposals, img_metas)
        else:
            raise NotImplementedError(
                f'{self.__class__.__name__} can not '
                f'be exported to ONNX. Please refer to the '
                f'list of supported models,'
                f'https://mmdetection.readthedocs.io/en/latest/tutorials/pytorch2onnx.html#list-of-supported-models-exportable-to-onnx'
                # noqa E501
            )

    def get_local_maximum(self, heat, kernel=3):
        """Extract local maximum pixel with given kernel.

        Args:
            heat (Tensor): Target heatmap.
            kernel (int): Kernel size of max pooling. Default: 3.

        Returns:
            heat (Tensor): A heatmap where local maximum pixels maintain its
                own value and other positions are 0.
        """
        pad = (kernel - 1) // 2
        hmax = F.max_pool2d(heat, kernel, stride=1, padding=pad)
        keep = (hmax == heat).float()
        return heat * keep