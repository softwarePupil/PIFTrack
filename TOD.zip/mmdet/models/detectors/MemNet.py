from ..builder import DETECTORS, build_neck, build_head
from .two_stage import TwoStageDetector
import pdb
import torch
from mmcv.cnn import ConvModule
from mmdet.core import bbox2result
import numpy as np
from collections import deque
from copy import deepcopy

@DETECTORS.register_module()
class FasterRCNNMem(TwoStageDetector):
    def __init__(self,
                 backbone,
                 rpn_head,
                 roi_head,
                 mem_reader,
                 mem_proj,
                 mem_size,
                 train_cfg,
                 test_cfg,
                 neck=None,
                 pretrained=None,
                 init_cfg=None):
        super(FasterRCNNMem, self).__init__(
            backbone=backbone,
            neck=neck,
            rpn_head=rpn_head,
            roi_head=roi_head,
            train_cfg=train_cfg,
            test_cfg=test_cfg,
            pretrained=pretrained,
            init_cfg=init_cfg)
        self.mem_reader = build_neck(mem_reader)
        self.mem_proj = build_neck(mem_proj)
        self.memory = deque()
        self.mem_size = mem_size
        self.prev_video = '000'

    def forward_train(self,
                      img,
                      img_metas,
                      gt_bboxes,
                      gt_labels,
                      gt_bboxes_ignore=None,
                      gt_masks=None,
                      proposals=None,
                      **kwargs):
        """
        Args:
            img (Tensor): of shape (N, C, H, W) encoding input images.
                Typically these should be mean centered and std scaled.
            prev_imgs(Tensor): of shape(sample_num, C, H, W).
                a list includes previous img, each img's shape is (1, C, H, W)

        Returns:
            dict[str, Tensor]: a dictionary of loss components
        """
        x = list(self.backbone(img))

        # TODO check the tensor whether can be a iterator
        prev_ks, prev_vs = [], []
        for key, value in kwargs.items():
            if 'prev_img' in key:
                with torch.no_grad():
                    prev_feature = self.backbone(value)[-1]
                prev_k, prev_v = self.mem_proj(prev_feature)
                prev_ks.append(prev_k)
                prev_vs.append(prev_v)
        prev_k = torch.stack(prev_ks, dim=2)
        prev_v = torch.stack(prev_vs, dim=2)
        # TODO 看看积累的是不是在第一个维度上
        cur_k, cur_v = self.mem_proj(x[-1])
        memout = self.mem_reader(cur_k, cur_v, prev_k, prev_v)

        x[-1] = memout
        x = self.neck(x)
        losses = dict()

        # RPN forward and loss
        if self.with_rpn:
            proposal_cfg = self.train_cfg.get('rpn_proposal',
                                              self.test_cfg.rpn)
            rpn_losses, proposal_list = self.rpn_head.forward_train(
                x,
                img_metas,
                gt_bboxes,
                gt_labels=None,
                gt_bboxes_ignore=gt_bboxes_ignore,
                proposal_cfg=proposal_cfg,
                **kwargs)
            losses.update(rpn_losses)
        else:
            proposal_list = proposals

        if not proposal_list: return losses
        roi_losses = self.roi_head.forward_train(x, img_metas, proposal_list,
                                                 gt_bboxes, gt_labels,
                                                 gt_bboxes_ignore, gt_masks,
                                                 **kwargs)
        losses.update(roi_losses)

        return losses

    def simple_test(self, img, img_metas, proposals=None, rescale=False):
        """Test without augmentation."""

        assert self.with_bbox, 'Bbox head must be implemented.'
        # TODO we should ensure the video is ordered
        # TODO use img_metas to clean self.memory
        frame_id = img_metas[0]['filename'].split('/')[-1].split('.')[0].split('_')[1]
        # 用frame_id 可能某些图片里面没有000001，用video_id判断更保险
        video_id = img_metas[0]['filename'].split('/')[-1].split('.')[0].split('_')[0]
        # if frame_id == '000001':
        #     # new video come in
        #     self.memory = deque()
        if video_id != self.prev_video:
            self.memory = deque()
            self.prev_video = video_id

        x = list(self.backbone(img))
        cur_k, cur_v = self.mem_proj(x[-1])
        if self.memory:
            if len(self.memory) > self.mem_size:
                #pdb.set_trace()
                self.memory.popleft()
            prev_k, prev_v = [x[0] for x in self.memory], [x[1] for x in self.memory]
            prev_k, prev_v = torch.stack(prev_k, dim=2), torch.stack(prev_v, dim=2)

            mem_out = self.mem_reader(cur_k, cur_v, prev_k, prev_v)
            x[-1] = mem_out

        x = self.neck(x)
        if proposals is None:
            proposal_list = self.rpn_head.simple_test_rpn(x, img_metas)
        else:
            proposal_list = proposals
        self.memory.append((cur_k, cur_v))
        return self.roi_head.simple_test(
            x, proposal_list, img_metas, rescale=rescale)


@DETECTORS.register_module()
class FasterRCNNMemSubt(TwoStageDetector):
    def __init__(self,
                 backbone,
                 rpn_head,
                 roi_head,
                 mem_reader,
                 mem_size,
                 train_cfg,
                 test_cfg,
                 neck=None,
                 pretrained=None,
                 init_cfg=None):
        super(FasterRCNNMemSubt, self).__init__(
            backbone=backbone,
            neck=neck,
            rpn_head=rpn_head,
            roi_head=roi_head,
            train_cfg=train_cfg,
            test_cfg=test_cfg,
            pretrained=pretrained,
            init_cfg=init_cfg)
        self.mem_reader = build_neck(mem_reader)
        self.memory = deque()
        self.mem_size = mem_size
        self.prev_video = '000'

    def forward_train(self,
                      img,
                      img_metas,
                      gt_bboxes,
                      gt_labels,
                      gt_bboxes_ignore=None,
                      gt_masks=None,
                      proposals=None,
                      **kwargs):
        """
        Args:
            img (Tensor): of shape (N, C, H, W) encoding input images.
                Typically these should be mean centered and std scaled.
            prev_imgs(Tensor): of shape(sample_num, C, H, W).
                a list includes previous img, each img's shape is (1, C, H, W)

        Returns:
            dict[str, Tensor]: a dictionary of loss components
        """
        x = list(self.backbone(img))

        # TODO check the tensor whether can be a iterator
        diff_features = []
        for key, value in kwargs.items():
            if 'prev_img' in key:
                with torch.no_grad():
                    prev_features = self.backbone(value)
                diff_feature = [x[i] - prev_features[i] for i in range(len(x))]
            diff_features.append(diff_feature)

        x = self.mem_reader(diff_features, x)
        x = self.neck(x)
        losses = dict()

        # RPN forward and loss
        if self.with_rpn:
            proposal_cfg = self.train_cfg.get('rpn_proposal',
                                              self.test_cfg.rpn)
            rpn_losses, proposal_list = self.rpn_head.forward_train(
                x,
                img_metas,
                gt_bboxes,
                gt_labels=None,
                gt_bboxes_ignore=gt_bboxes_ignore,
                proposal_cfg=proposal_cfg,
                **kwargs)
            losses.update(rpn_losses)
        else:
            proposal_list = proposals

        if not proposal_list: return losses
        roi_losses = self.roi_head.forward_train(x, img_metas, proposal_list,
                                                 gt_bboxes, gt_labels,
                                                 gt_bboxes_ignore, gt_masks,
                                                 **kwargs)
        losses.update(roi_losses)

        return losses

    def simple_test(self, img, img_metas, proposals=None, rescale=False):
        """Test without augmentation."""

        assert self.with_bbox, 'Bbox head must be implemented.'
        # TODO we should ensure the video is ordered
        # TODO use img_metas to clean self.memory
        frame_id = img_metas[0]['filename'].split('/')[-1].split('.')[0].split('_')[1]
        # 用frame_id 可能某些图片里面没有000001，用video_id判断更保险
        video_id = img_metas[0]['filename'].split('/')[-1].split('.')[0].split('_')[0]
        # if frame_id == '000001':
        #     # new video come in
        #     self.memory = deque()
        if video_id != self.prev_video:
            self.memory = deque()
            self.prev_video = video_id

        x = list(self.backbone(img))
        x_save = deepcopy(x)

        if self.memory:
            if len(self.memory) > self.mem_size:
                self.memory.popleft()
            prev_features = []
            #pdb.set_trace()
            for mem in self.memory:
                prev_feature = [x[i]-mem[i] for i in range(len(x))]
            prev_features.append(prev_feature)

            x = self.mem_reader(prev_features, x)
        else:
            self.memory.append(x_save)
            return [[np.array([])]]

        x = self.neck(x)
        if proposals is None:
            proposal_list = self.rpn_head.simple_test_rpn(x, img_metas)
        else:
            proposal_list = proposals
        self.memory.append(x_save)
        return self.roi_head.simple_test(
            x, proposal_list, img_metas, rescale=rescale)

# 输出差分图像用于检测
@DETECTORS.register_module()
class FasterRCNNMemSubt1(TwoStageDetector):
    def __init__(self,
                 backbone,
                 rpn_head,
                 roi_head,
                 mem_size,
                 train_cfg,
                 test_cfg,
                 neck=None,
                 pretrained=None,
                 init_cfg=None):
        super(FasterRCNNMemSubt1, self).__init__(
            backbone=backbone,
            neck=neck,
            rpn_head=rpn_head,
            roi_head=roi_head,
            train_cfg=train_cfg,
            test_cfg=test_cfg,
            pretrained=pretrained,
            init_cfg=init_cfg)

        self.memory = deque()
        self.mem_size = mem_size
        self.prev_video = '000'

        rpn_train_cfg = train_cfg.rpn if train_cfg is not None else None
        rpn_head_ = rpn_head.copy()
        rpn_head_.update(train_cfg=rpn_train_cfg, test_cfg=test_cfg.rpn)
        self.diff_rpn_head = build_head(rpn_head_)

        rcnn_train_cfg = train_cfg.rcnn if train_cfg is not None else None
        roi_head.update(train_cfg=rcnn_train_cfg)
        roi_head.update(test_cfg=test_cfg.rcnn)
        roi_head.pretrained = pretrained
        self.diff_roi_head = build_head(roi_head)

    def _det_train(self, losses, x, img_metas,
                   gt_bboxes, gt_labels, gt_bboxes_ignore, gt_masks,
                   prefix, proposals=None, mode='origin', **kwargs):
        if mode == 'origin':
            rpn_head = self.rpn_head
            roi_head = self.roi_head
        elif mode == 'diff':
            rpn_head = self.diff_rpn_head
            roi_head = self.diff_roi_head
        else:
            raise ValueError("mode is not right for now")

        if self.with_rpn:
            proposal_cfg = self.train_cfg.get('rpn_proposal',
                                              self.test_cfg.rpn)
            rpn_losses, proposal_list = rpn_head.forward_train(
                x,
                img_metas,
                gt_bboxes,
                gt_labels=None,
                gt_bboxes_ignore=gt_bboxes_ignore,
                proposal_cfg=proposal_cfg,
                **kwargs)
            for key, value in rpn_losses.items():
                losses[prefix+'_'+key] = value

        else:
            proposal_list = proposals

        if not proposal_list: return losses
        roi_losses = roi_head.forward_train(x, img_metas, proposal_list,
                                                 gt_bboxes, gt_labels,
                                                 gt_bboxes_ignore, gt_masks,
                                                 **kwargs)
        for key, value in roi_losses.items():
            losses[prefix + '_' + key] = value


    def forward_train(self,
                      img,
                      img_metas,
                      gt_bboxes,
                      gt_labels,
                      gt_bboxes_ignore=None,
                      gt_masks=None,
                      proposals=None,
                      **kwargs):
        """
        Args:
            img (Tensor): of shape (N, C, H, W) encoding input images.
                Typically these should be mean centered and std scaled.
            prev_imgs(Tensor): of shape(sample_num, C, H, W).
                a list includes previous img, each img's shape is (1, C, H, W)

        Returns:
            dict[str, Tensor]: a dictionary of loss components
        """
        x = list(self.backbone(img))
        # TODO check the tensor whether can be a iterator
        diff_features = []
        for key, value in kwargs.items():
            if 'prev_img' in key:
                with torch.no_grad():
                    prev_features = self.backbone(value)
                diff_feature = [x[i] - prev_features[i] for i in range(len(x))]
            diff_features.append(diff_feature)

        diff_feature = []
        for i in range(len(x)):
            temp = [diff_features[j][i] for j in range(len(diff_features))]
            diff_feature.append(torch.stack(temp, dim=-1).mean(-1))
        diff_feature = self.neck(diff_feature)
        x = self.neck(x)
        losses = dict()

        # RPN forward and loss
        self._det_train(losses, x, img_metas, gt_bboxes, gt_labels, gt_bboxes_ignore, gt_masks, \
                        'Origin', mode='origin')
        self._det_train(losses, diff_feature, img_metas, gt_bboxes, gt_labels, gt_bboxes_ignore, gt_masks, \
                        'Subtra', mode='diff')

        return losses

    def simple_test(self, img, img_metas, proposals=None, rescale=False):
        """Test without augmentation."""

        assert self.with_bbox, 'Bbox head must be implemented.'
        # TODO we should ensure the video is ordered
        # TODO use img_metas to clean self.memory
        frame_id = img_metas[0]['filename'].split('/')[-1].split('.')[0].split('_')[1]
        # 用frame_id 可能某些图片里面没有000001，用video_id判断更保险
        video_id = img_metas[0]['filename'].split('/')[-1].split('.')[0].split('_')[0]
        # if frame_id == '000001':
        #     # new video come in
        #     self.memory = deque()
        if video_id != self.prev_video:
            self.memory = deque()
            self.prev_video = video_id


        x = list(self.backbone(img))
        x_save = deepcopy(x)

        if self.memory:
            if len(self.memory) > self.mem_size:
                self.memory.popleft()
            prev_features = []

            #pdb.set_trace()
            ###debug
            # aa = x[0]-self.memory[-1][0]
            # aa = aa[0,0].detach().cpu().numpy()
            # aa = x[0][0,0].detach().cpu().numpy()
            # aa = self.memory[-1][0][0, 0].detach().cpu().numpy()
            # cc = (255*(aa-aa.min())/(aa.max()-aa.min())).astype('uint8')
            # cv2.imwrite('diff_feature.jpg', cc)
            ###
            for mem in self.memory:
                prev_feature = [x[i]-mem[i] for i in range(len(x))]
            prev_features.append(prev_feature)
            diff_feature = []

            for i in range(len(x)):
                temp = [prev_features[j][i] for j in range(len(prev_features))]
                diff_feature.append(torch.stack(temp, dim=-1).mean(-1))
        else:
            self.memory.append(x_save)
            return [[np.array([])]]

        # TODO 检查测试是否正确
        # x = self.neck(x)
        # if proposals is None:
        #     proposal_list = self.rpn_head.simple_test_rpn(x, img_metas)
        # else:
        #     proposal_list = proposals
        # ori_result = self.roi_head.simple_test(
        #     x, proposal_list, img_metas, rescale=rescale)

        diff_feature = self.neck(diff_feature)
        if proposals is None:
            proposal_list = self.diff_rpn_head.simple_test_rpn(diff_feature, img_metas)
        else:
            proposal_list = proposals
        diff_result = self.diff_roi_head.simple_test(
            diff_feature, proposal_list, img_metas, rescale=rescale)
        self.memory.append(x_save)

        return diff_result
        # return ori_result


        # result = np.concatenate([ori_result[0][0], diff_result[0][0]], axis=0)
        # return [[result]]


@DETECTORS.register_module()
class FasterRCNNMemAdd(TwoStageDetector):
    def __init__(self,
                 backbone,
                 rpn_head,
                 roi_head,
                 mem_reader,
                 mem_size,
                 train_cfg,
                 test_cfg,
                 neck=None,
                 pretrained=None,
                 init_cfg=None):
        super(FasterRCNNMemAdd, self).__init__(
            backbone=backbone,
            neck=neck,
            rpn_head=rpn_head,
            roi_head=roi_head,
            train_cfg=train_cfg,
            test_cfg=test_cfg,
            pretrained=pretrained,
            init_cfg=init_cfg)
        self.mem_reader = build_neck(mem_reader)
        self.memory = deque()
        self.mem_size = mem_size
        self.prev_video = '000'

    def forward_train(self,
                      img,
                      img_metas,
                      gt_bboxes,
                      gt_labels,
                      gt_bboxes_ignore=None,
                      gt_masks=None,
                      proposals=None,
                      **kwargs):
        """
        Args:
            img (Tensor): of shape (N, C, H, W) encoding input images.
                Typically these should be mean centered and std scaled.
            prev_imgs(Tensor): of shape(sample_num, C, H, W).
                a list includes previous img, each img's shape is (1, C, H, W)

        Returns:
            dict[str, Tensor]: a dictionary of loss components
        """
        x = list(self.backbone(img))

        # TODO check the tensor whether can be a iterator
        features = []
        for key, value in kwargs.items():
            if 'prev_img' in key:
                with torch.no_grad():
                    prev_features = self.backbone(value)

            features.append(prev_features)

        x = self.mem_reader(features, x)
        x = self.neck(x)
        losses = dict()

        # RPN forward and loss
        if self.with_rpn:
            proposal_cfg = self.train_cfg.get('rpn_proposal',
                                              self.test_cfg.rpn)
            rpn_losses, proposal_list = self.rpn_head.forward_train(
                x,
                img_metas,
                gt_bboxes,
                gt_labels=None,
                gt_bboxes_ignore=gt_bboxes_ignore,
                proposal_cfg=proposal_cfg,
                **kwargs)
            losses.update(rpn_losses)
        else:
            proposal_list = proposals

        if not proposal_list: return losses
        roi_losses = self.roi_head.forward_train(x, img_metas, proposal_list,
                                                 gt_bboxes, gt_labels,
                                                 gt_bboxes_ignore, gt_masks,
                                                 **kwargs)
        losses.update(roi_losses)

        return losses

    def simple_test(self, img, img_metas, proposals=None, rescale=False):
        """Test without augmentation."""

        assert self.with_bbox, 'Bbox head must be implemented.'
        # TODO we should ensure the video is ordered
        # TODO use img_metas to clean self.memory
        frame_id = img_metas[0]['filename'].split('/')[-1].split('.')[0].split('_')[1]
        # 用frame_id 可能某些图片里面没有000001，用video_id判断更保险
        video_id = img_metas[0]['filename'].split('/')[-1].split('.')[0].split('_')[0]
        # if frame_id == '000001':
        #     # new video come in
        #     self.memory = deque()
        if video_id != self.prev_video:
            self.memory = deque()
            self.prev_video = video_id

        x = list(self.backbone(img))
        x_save = deepcopy(x)

        if self.memory:
            if len(self.memory) > self.mem_size:
                self.memory.popleft()

            prev_features = self.memory
            x = self.mem_reader(prev_features, x)
        else:
            self.memory.append(x_save)
            return [[np.array([])]]

        x = self.neck(x)
        if proposals is None:
            proposal_list = self.rpn_head.simple_test_rpn(x, img_metas)
        else:
            proposal_list = proposals
        self.memory.append(x_save)
        return self.roi_head.simple_test(
            x, proposal_list, img_metas, rescale=rescale)