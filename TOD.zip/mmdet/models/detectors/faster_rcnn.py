# Copyright (c) OpenMMLab. All rights reserved.
from ..builder import DETECTORS
from .two_stage import TwoStageDetector
import pdb
import torch
from mmcv.cnn import ConvModule
from mmdet.core import bbox2result
import numpy as np

@DETECTORS.register_module()
class FasterRCNN(TwoStageDetector):
    """Implementation of `Faster R-CNN <https://arxiv.org/abs/1506.01497>`_"""

    def __init__(self,
                 backbone,
                 rpn_head,
                 roi_head,
                 train_cfg,
                 test_cfg,
                 neck=None,
                 pretrained=None,
                 init_cfg=None):
        super(FasterRCNN, self).__init__(
            backbone=backbone,
            neck=neck,
            rpn_head=rpn_head,
            roi_head=roi_head,
            train_cfg=train_cfg,
            test_cfg=test_cfg,
            pretrained=pretrained,
            init_cfg=init_cfg)


@DETECTORS.register_module()
class FasterRCNN_TFFL(TwoStageDetector):
    """Temporal Fusion in Feature Level"""

    def __init__(self,
                 in_channels,
                 backbone,
                 rpn_head,
                 roi_head,
                 train_cfg,
                 test_cfg,
                 neck=None,
                 pretrained=None,
                 init_cfg=None,
                 resume=None):
        super(FasterRCNN_TFFL, self).__init__(
            backbone=backbone,
            neck=neck,
            rpn_head=rpn_head,
            roi_head=roi_head,
            train_cfg=train_cfg,
            test_cfg=test_cfg,
            pretrained=pretrained,
            init_cfg=init_cfg)
        # TODO 在这里能不能直接把backbone 和neck直接eval?
        #pdb.set_trace()
        self.backbone.eval()
        self.neck.eval()
        #for param in self.backbone.paramters():
        #    param.requires_grad = False
        #for param in self.neck.paramters():
        #    param.requires_grad = False

        # TODO 对backbone 和 neck加载数据
        self.lateral_conv_1x1 = ConvModule(
            in_channels,
            in_channels // 3,
            1,
            padding=0,
            inplace=False
        )
        self.lateral_conv_3x3 = ConvModule(
            in_channels,
            in_channels // 3 ,
            3,
            padding=1,
            inplace=False
        )

    def extract_feat(self, img):
        #batch, c, h, w = img.shape
        ans = []
        num_outs = self.neck.num_outs

        #aa =  x[1][0,0].cpu().numpy()
        #aa = (aa - aa.min())/(aa.max()-aa.min())
        #aa = (aa*255).astype('uint8')
        #aa=cv2.applyColorMap(aa, cv2.COLORMAP_JET)
        #cv2.imwrite('1pre.jpg', aa)
        #cv2.imwrite('1pre_bigFuse8.jpg', aa)
        with torch.no_grad():
            for i in range(0, 6, 2):
                x = self.backbone(img[:,(i*3):(i+3)*3])
                if self.with_neck:
                    x = self.neck(x)
                pdb.set_trace()
                if len(ans) == 0:
                    ans = list(x[:num_outs])
                else:
                    for j in range(num_outs):
                        ans[j] = torch.cat([ans[j], x[j]], dim=1)
        #pdb.set_trace()
        for i in range(num_outs):
            ans[i] = self.lateral_conv_3x3(ans[i]) + self.lateral_conv_1x1(ans[i])
        return ans

    def simple_test(self, img, img_metas, proposals=None, rescale=False):


        assert self.with_bbox, 'Bbox head must be implemented.'
        x = self.extract_feat(img)
        if proposals is None:
            proposal_list = self.rpn_head.simple_test_rpn(x, img_metas)
        else:
            proposal_list = self.rpn_head.simple_test_rpn(x, img_metas)
            proposals = torch.tensor(proposals, dtype=proposal_list[0].dtype, device=proposal_list[0].device)
            proposal_list = torch.cat([proposal_list[0], proposals], dim=0)
            #pdb.set_trace()
            proposal_list = [proposal_list]

            #proposal_list = proposals


        return self.roi_head.simple_test(x, proposal_list, img_metas, rescale=rescale)

    '''
    def simple_test(self, img, img_metas, proposals=None, rescale=False):
        """Test without augmentation."""

        assert self.with_bbox, 'Bbox head must be implemented.'
        x = self.extract_feat(img)
        if proposals is None:
            proposal_list = self.rpn_head.simple_test_rpn(x, img_metas)
        else:
            proposal_list = proposals
        #pdb.set_trace()
        det = proposal_list[0]
        mask = det[:, -1] > 0.9
        det = det[mask]
        label = det.new_zeros(det.shape[0])
        dets = bbox2result(det, label, 1)
        return [dets]
        return self.roi_head.simple_test(
            x, proposal_list, img_metas, rescale=rescale)
    '''

    # Note: 使用9张图的合成
    # def extract_feat(self, img):
    #
    #     #pdb.set_trace()
    #     batch,c,h,w = img.shape
    #     img = img.view(batch, 3, 9, h, w)
    #     # TODO 目前使用加法
    #     ans = []
    #     num_outs = self.neck.num_outs
    #     with torch.no_grad():
    #         for i in range(3):
    #             x = self.backbone(img[:,i])
    #             if self.with_neck:
    #                 x = self.neck(x)
    #             if len(ans) == 0:
    #                 ans = list(x[:num_outs])
    #             else:
    #                 for i in range(num_outs):
    #                     ans[i] = ans[i] + x[i]
    #
    #     return ans

import numpy as np

def linear_assignment(cost_matrix):
    try:
        import lap
        _, x, y = lap.lapjv(cost_matrix, extend_cost=True)
        return np.array([[y[i], i] for i in x if i >= 0])  #
    except ImportError:
        from scipy.optimize import linear_sum_assignment
        x, y = linear_sum_assignment(cost_matrix)
        return np.array(list(zip(x, y)))
def iou_batch(bb_test, bb_gt):
    """
    From SORT: Computes IOU between two bboxes in the form [x1,y1,x2,y2]
    """
    bb_gt = np.expand_dims(bb_gt, 0)
    bb_test = np.expand_dims(bb_test, 1)

    xx1 = np.maximum(bb_test[..., 0], bb_gt[..., 0])
    yy1 = np.maximum(bb_test[..., 1], bb_gt[..., 1])
    xx2 = np.minimum(bb_test[..., 2], bb_gt[..., 2])
    yy2 = np.minimum(bb_test[..., 3], bb_gt[..., 3])
    w = np.maximum(0., xx2 - xx1)
    h = np.maximum(0., yy2 - yy1)
    wh = w * h
    o = wh / ((bb_test[..., 2] - bb_test[..., 0]) * (bb_test[..., 3] - bb_test[..., 1])
              + (bb_gt[..., 2] - bb_gt[..., 0]) * (bb_gt[..., 3] - bb_gt[..., 1]) - wh)
    return (o)
def associate_detections_to_trackers(detections, trackers, iou_threshold=0.3):
    """
    Assigns detections to tracked object (both represented as bounding boxes)
    Returns 3 lists of matches, unmatched_detections and unmatched_trackers
    """
    if (len(trackers) == 0):
        return np.empty((0, 2), dtype=int), np.arange(len(detections)), np.empty((0, 5), dtype=int)
    #pdb.set_trace()
    iou_matrix = iou_batch(detections, trackers)

    if min(iou_matrix.shape) > 0:
        a = (iou_matrix > iou_threshold).astype(np.int32)
        if a.sum(1).max() == 1 and a.sum(0).max() == 1:
            # 每个det和tck都只被一个匹配，就可以直接match
            matched_indices = np.stack(np.where(a), axis=1)
        else:
            matched_indices = linear_assignment(-iou_matrix)
    else:
        matched_indices = np.empty(shape=(0, 2))

    unmatched_detections = []
    for d, det in enumerate(detections):
        if (d not in matched_indices[:, 0]):
            unmatched_detections.append(d)
    unmatched_trackers = []
    for t, trk in enumerate(trackers):
        if (t not in matched_indices[:, 1]):
            unmatched_trackers.append(t)

    return np.array(unmatched_detections), np.array(unmatched_trackers)

@DETECTORS.register_module()
class FasterRCNN_track(FasterRCNN):

    def simple_test(self, img, img_metas, sort=None, proposals=None, rescale=False):


        assert self.with_bbox, 'Bbox head must be implemented.'
        x = self.extract_feat(img)
        proposal_list = self.rpn_head.simple_test_rpn(x, img_metas)
        cur_result = self.roi_head.simple_test(x, proposal_list, img_metas, rescale=rescale)[0][0]

        if isinstance(proposals, np.ndarray):
            if not proposals.any(): return cur_result
            if proposals.ndim==1: proposals = proposals[np.newaxis, :]
            #pdb.set_trace()

            try:unmatched_det, unmatched_trk = associate_detections_to_trackers(cur_result, proposals)
            except: pdb.set_trace()

            final_proposal = []

            #if unmatched_trk.any():print('The num of unmatched trk %d'%unmatched_trk.shape[0])
            for i in unmatched_trk:
                final_proposal.append(proposals[i])
            final_proposal = torch.tensor(final_proposal, dtype=proposal_list[0].dtype, device=proposal_list[0].device)
            new_result = self.roi_head.simple_test(x, [final_proposal], img_metas, rescale=rescale)[0][0]
            return np.concatenate([cur_result, new_result], axis=0)

        return cur_result


@DETECTORS.register_module()
class FasterRCNN_RPN(FasterRCNN):
    def simple_test(self, img, img_metas, proposals=None, rescale=False):
        """Test without augmentation."""

        assert self.with_bbox, 'Bbox head must be implemented.'
        x = self.extract_feat(img)
        if proposals is None:
            proposal_list = self.rpn_head.simple_test_rpn(x, img_metas)
        else:
            proposal_list = proposals
        #pdb.set_trace()
        mlvl_dets = proposal_list[0]
        mlvl_results = []
        #pdb.set_trace()
        for level in range(len(mlvl_dets)):

            mask = mlvl_dets[level][:, -1] > 0.95
            det = mlvl_dets[level][mask]
            label = det.new_zeros(det.shape[0])
            # dets the first is batch, the second is label
            dets = bbox2result(det, label, 1)
            for label in range(len(dets)):
                #pdb.set_trace()
                if not dets[label].any(): continue
                if label >= len(mlvl_results):
                    mlvl_results.append(dets[label])
                else:
                    #pdb.set_trace()
                    mlvl_results[label] = np.concatenate([mlvl_results[label], dets[label]], axis=0)

        #pdb.set_trace()
        return [mlvl_results]

