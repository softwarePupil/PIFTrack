import pdb

import torch.nn as nn
import torch.nn.functional as F
from mmcv.cnn import ConvModule
from mmdet.models.utils import InvertedResidual
from mmcv.runner import BaseModule, auto_fp16

from ..builder import NECKS
import torch
from math import sqrt, log


class UpsampleBlock(nn.Module):
    def __init__(self, in_channels, lateral_c,  scale_factor=2):
        super().__init__()
        self.lateral = nn.Conv2d(in_channels, lateral_c, kernel_size=3, padding=1)
        self.fusion = nn.Conv2d(lateral_c, lateral_c, kernel_size=1)
        self.scale_factor = scale_factor

    def forward(self, skip_f, up_f):
        x = self.lateral(skip_f)
        x = x + F.interpolate(up_f, scale_factor=self.scale_factor, mode='bilinear', align_corners=False)
        x = self.fusion(x)
        return x

@NECKS.register_module()
class MemDecoder(BaseModule):
    def __init__(self,
                 in_channels,
                 lateral_channels,
                 out_channels,
                 times_up,
                 init_cfg=None):
        super(MemDecoder, self).__init__(init_cfg)
        # in_channels = [1024,1024,512,256]
        self.fp16_enabled = False
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.times_up = times_up
        self.deconv_layers = self._make_deconv_layer()



    @auto_fp16()
    def forward(self, x, memout):
        out = self.deconv_layers(x[-1])
        return out,


@NECKS.register_module()
class MemProj(BaseModule):

    def positionalencoding2d(self, d_model, height, width):
        # code from https://github.com/wzlxjtu/PositionalEncoding2D/blob/master/positionalembedding2d.py
        """
        :param d_model: dimension of the model
        :param height: height of the positions
        :param width: width of the positions
        :return: d_model*height*width position matrix
        """
        if d_model % 4 != 0:
            raise ValueError("Cannot use sin/cos positional encoding with "
                             "odd dimension (got dim={:d})".format(d_model))
        pe = torch.zeros(d_model, height, width)
        # Each dimension use half of d_model
        d_model = int(d_model / 2)
        div_term = torch.exp(torch.arange(0., d_model, 2) *
                             -(log(10000.0) / d_model))
        pos_w = torch.arange(0., width).unsqueeze(1)
        pos_h = torch.arange(0., height).unsqueeze(1)
        pe[0:d_model:2, :, :] = torch.sin(pos_w * div_term).transpose(0, 1).unsqueeze(1).repeat(1, height, 1)
        pe[1:d_model:2, :, :] = torch.cos(pos_w * div_term).transpose(0, 1).unsqueeze(1).repeat(1, height, 1)
        pe[d_model::2, :, :] = torch.sin(pos_h * div_term).transpose(0, 1).unsqueeze(2).repeat(1, 1, width)
        pe[d_model + 1::2, :, :] = torch.cos(pos_h * div_term).transpose(0, 1).unsqueeze(2).repeat(1, 1, width)

        return pe.unsqueeze(0)

    def __init__(self,
                 in_channels,
                 key_channels,
                 value_channels,
                 init_cfg=dict(
                     type='Xavier', layer='Conv2d', distribution='uniform')):
        super(MemProj, self).__init__(init_cfg)
        self.key_channels = key_channels
        self.value_channels = value_channels
        self.key_proj = nn.Conv2d(in_channels, key_channels, 3, padding=1)
        self.value_proj = nn.Conv2d(in_channels, value_channels, 3, padding=1)

    # def init_weights(self):
    #     # At training , make the model only focus on the current frame
    #     #pdb.set_trace()
    #     nn.init.constant_(self.key_proj.weight, 0)
    #     nn.init.constant_(self.key_proj.bias, 0)

    def forward(self, x):
        #pdb.set_trace()
        _, _, h, w = x.shape
        #key_pos = self.positionalencoding2d(self.key_channels, h ,w)
        #value_pos = self.positionalencoding2d(self.value_channels, h, w)
        key = self.key_proj(x)
        value = self.value_proj(x)
        return key, value


@NECKS.register_module()
class MemReader(BaseModule):
    def __init__(self,
                 use_SA=False,
                 head_num=0,
                 init_cfg=dict(
                     type='Xavier', layer='Conv2d', distribution='uniform')):

        super(MemReader, self).__init__(init_cfg)


    def forward(self, cur_k, cur_v, prev_k, prev_v):

        b, kc, h, w = cur_k.shape
        _, vc, prev_n, _, _ = prev_v.shape
        cur_k = cur_k.permute(0, 2, 3, 1).contiguous().view(b, h * w, kc)

        # check the dim is right or not
        pdb.set_trace()
        prev_k = prev_k.view(b, kc, prev_n*h*w)
        prev_v = prev_v.permute(0, 2, 3, 4, 1).contiguous().view(b, prev_n*h*w, vc)

        # To prevent the exp overflow softmax
        # https://zhuanlan.zhihu.com/p/29376573
        # product attention
        similarity_map = torch.bmm(cur_k, prev_k)/sqrt(kc)
        similarity_map = similarity_map.softmax(dim=2)
        #pdb.set_trace()

        new_value = torch.bmm(similarity_map, prev_v)
        new_value = new_value.permute(0,2,1).view(b, vc, h, w)

        mem_out = torch.cat([cur_v, new_value], dim=1)
        pdb.set_trace()
        # mem_out = (cur_v + new_value) / 2
        return mem_out

@NECKS.register_module()
class MemReaderSubt(BaseModule):
    def __init__(self,
                 in_channels,
                 init_cfg=dict(
                     type='Xavier', layer='Conv2d', distribution='uniform')):
        self.in_channels = in_channels
        super(MemReaderSubt, self).__init__(init_cfg)
        self.diff_layer = self.init_diff_layer()

    def init_diff_layer(self):
        diff_layer = nn.ModuleList()
        for i in range(4):
            #TODO it should use GN
            diff_layer.append(nn.Sequential(
                nn.Conv2d(self.in_channels[i], 1024, 1, bias=True),
                nn.Conv2d(1024, 1024, 3, padding=1, groups=1024, bias=False),
                nn.Conv2d(1024, self.in_channels[i], 1, bias=True),
                nn.Sigmoid(),
            ))
        return diff_layer

    def forward(self, diff_features, x):
        #pdb.set_trace()
        # TODO 先学习TDN用mean的形式吧
        #spdb.set_trace()

        for i in range(len(x)):
            diff_inp = [diff_features[j][i] for j in range(len(diff_features))]
            diff_inp = torch.stack(diff_inp, dim=-1).mean(dim=-1)
            x[i] = x[i] + self.diff_layer[i](diff_inp)*x[i]


        # debug
        # aa = x[i][0].mean(0).cpu().numpy()
        # aa = self.diff_layer[i](diff_inp)[0].mean(0).cpu().numpy()
        # cc = (aa-aa.min())/(aa.max()-aa.min())*255
        # cc = cc.astype('uint8')

        # out = x*1
        # #pdb.set_trace()
        # for i in range(len(x)):
        #     # Note use `torch.histc` to gen a hist, what the hist I want is
        #     # the num of `0` is the biggest, then decrese slowly
        #     for diff in diff_features:
        #         #pdb.set_trace()
        #         #ones += diff[i].abs().tanh()
        #         out[i] = out[i] + x[i]*self.diff_layer[i](diff[i])/len(diff_features) # use the maginitude of subtraction
        #
        return x


@NECKS.register_module()
class MemReaderSubt_Cat(BaseModule):
    def __init__(self,
                 in_channels,
                 init_cfg=dict(
                     type='Xavier', layer='Conv2d', distribution='uniform')):
        self.in_channels = in_channels
        super(MemReaderSubt_Cat, self).__init__(init_cfg)


    def forward(self, diff_features, x):
        #pdb.set_trace()

        for i in range(len(x)):
            diffs = []
            # Note use `torch.histc` to gen a hist, what the hist I want is
            # the num of `0` is the biggest, then decrese slowly
            for diff in diff_features:
                diffs.append(diff[i])
            diffs = torch.stack(diffs, -1).abs().max(-1)[0]
            x[i] = torch.cat([x[i], diffs], 1)
        return x

@NECKS.register_module()
class MemReaderAdd(BaseModule):
    def __init__(self,
                 in_channels,
                 init_cfg=dict(
                     type='Xavier', layer='Conv2d', distribution='uniform')):
        self.in_channels = in_channels
        super(MemReaderAdd, self).__init__(init_cfg)


    def forward(self, features, x):
        #pdb.set_trace()
        # TODO 先学习TDN用mean的形式吧
        #spdb.set_trace()

        for i in range(len(x)):
            inp = [features[j][i] for j in range(len(features))]
            inp = torch.stack(inp, dim=-1).mean(dim=-1)
            x[i] = x[i] + inp
        return x

# Pure version dot
@NECKS.register_module()
class MemReaderOld(BaseModule):
    def __init__(self,
                 in_channels,
                 feat_channels,
                 use_SA=False,
                 head_num=0,
                 init_cfg=dict(
                     type='Xavier', layer='Conv2d', distribution='uniform')):

        super(MemReaderOld, self).__init__(init_cfg)
        self.proj_k = ConvModule(in_channels, feat_channels, 3, padding=1)
        self.proj_v = ConvModule(in_channels, feat_channels, 3, padding=1)
        self.feat_aggregate = ConvModule(feat_channels*2, feat_channels, 1)

    def forward(self, feat, prev_feats):
        k_feat, v_feat = self.proj_k(feat), self.proj_v(feat)
        b, c, h, w = k_feat.shape
        k_feat = k_feat.permute(0, 2, 3, 1).contiguous().view(b, h * w, c)

        #pdb.set_trace()
        for prev_feat in prev_feats:
            k_prev, v_prev = self.proj_k(prev_feat), self.proj_v(prev_feat)
            k_prev = k_prev.view(b, c, h*w)
            v_prev = v_prev.permute(0,2,3,1).contiguous().view(b, h*w, c)
            # TODO check the result is (b, h*w, h*w) or note
            similarity_map = torch.bmm(k_feat, k_prev)
            new_value = torch.bmm(similarity_map, v_prev)
            new_value = new_value.permute(0,2,1).view(b, c, h, w)
            # TODO 这种形式的feat_aggregate 合适么， 如果不想这样，就必须把memory里面的feat给融合，
            # 用卷积融合还不合适，似乎还只能用avg或者max进行分组融合
            v_feat = self.feat_aggregate(torch.cat([v_feat, new_value], dim=1))
        return v_feat,


