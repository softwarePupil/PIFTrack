import warnings
from abc import abstractmethod

import torch
import torch.nn as nn
from mmcv.runner import force_fp32

from mmdet.core import build_bbox_coder, multi_apply
from ..builder import HEADS, build_loss
from .base_dense_head import BaseDenseHead
from mmcv.cnn import bias_init_with_prob, normal_init
from mmdet.models.utils import gen_gaussian_target
from .dense_test_mixins import BBoxTestMixin
from mmcv.cnn import ConvModule
import pdb
from torchvision.transforms import functional as TF


@HEADS.register_module()
class RoadMapHead(BaseDenseHead,BBoxTestMixin):
    def __init__(self,
                 in_channels,
                 num_classes,
                 radius_overlap=0.3,
                 loss_seg=dict(type='CrossEntropyLoss', use_sigmoid=False, loss_weight=1.0),
                 loss_center_heatmap=dict(
                     type='GaussianFocalLoss', loss_weight=1.0),
                 init_cfg=None):
        super(RoadMapHead, self).__init__(init_cfg)
        self.radiu_overlap = radius_overlap
        self.in_channels = in_channels
        self.feat_channels = in_channels
        self.num_classes = num_classes
        self.loss_center_heatmap = build_loss(loss_center_heatmap)
        self.loss_seg = build_loss(loss_seg)

        self.heatmap_head = self._build_head(in_channels, in_channels, 1)
        self.roadmap_head = self._build_head(in_channels, in_channels, 2)

        ##################################################
        self.iter = 0

    def init_weights(self):
        """Initialize weights of the head."""
        bias_init = bias_init_with_prob(0.1)
        self.heatmap_head[-1].bias.data.fill_(bias_init)
        #self.road_head[-1].bias.data.fill_(bias_init = bias_init_with_prob(0.7))

    def _build_head(self, in_channel, feat_channel, out_channel):
        """Build head for each branch."""
        layer = nn.Sequential(
            nn.Conv2d(in_channel, feat_channel, kernel_size=3, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(feat_channel, out_channel, kernel_size=1))
        return layer

    def forward(self, feats):
        return multi_apply(self.forward_single, feats)

    def forward_single(self, feat):
        #pdb.set_trace()
        center_heatmap_pred = self.heatmap_head(feat).sigmoid()
        road_pred = self.roadmap_head(feat)

        return center_heatmap_pred, road_pred

    def forward_train(self,
                      x,
                      img_metas,
                      gt_bboxes,
                      gt_road_seg,
                      gt_labels=None,
                      gt_bboxes_ignore=None,
                      proposal_cfg=None,
                      **kwargs):

        outs = self(x)
        #pdb.set_trace()
        if gt_labels is None:
            loss_inputs = outs + (gt_bboxes, gt_road_seg, img_metas)
        else:
            loss_inputs = outs + (gt_bboxes, gt_road_seg, gt_labels, img_metas)
        losses = self.loss(*loss_inputs, gt_bboxes_ignore=gt_bboxes_ignore)
        if proposal_cfg is None:
            return outs, losses
        else:
            proposal_list = self.get_bboxes(
                *outs, img_metas=img_metas, cfg=proposal_cfg)
            return outs, losses, proposal_list


    @force_fp32(apply_to=('center_heatmap_preds', 'road_preds'))
    def loss(self,
             center_heatmap_preds,
             road_preds,
             gt_bboxes,
             gt_road_seg,
             gt_labels,
             img_metas,
             gt_bboxes_ignore=None):

        center_heatmap_pred = center_heatmap_preds[0]
        road_pred = road_preds[0]

        center_heatmap_target, avg_factor = self.get_targets(gt_bboxes, gt_labels,
                                                             center_heatmap_pred.shape,
                                                             img_metas[0]['pad_shape'])
        #self.iter += 1
        #if self.iter % 50 == 0:
        #    pdb.set_trace()
        loss_center_heatmap = self.loss_center_heatmap(
            center_heatmap_pred, center_heatmap_target, avg_factor=avg_factor)
        if self.loss_seg.use_sigmoid:
            batch, c, h, w = road_pred.shape
            seg_scores = road_pred.view(-1)
        else:
            batch, c, h, w = road_pred.shape
            seg_scores = road_pred.permute(0, 2, 3, 1).contiguous().view(-1, c)
        gt_road_seg = TF.resize(gt_road_seg, (h, w))
        gt_road_seg = gt_road_seg.reshape(-1)

        if not (gt_road_seg.min().item() >= 0 and gt_road_seg.max().item() <= 1):
            pdb.set_trace()
        loss_seg = self.loss_seg(seg_scores, gt_road_seg.type(torch.int64))
        return dict(
            loss_center_heatmap=loss_center_heatmap,
            loss_seg=loss_seg
        )

    def get_targets(self, gt_bboxes, gt_labels, feat_shape, img_shape):
        """Compute regression and classification targets in multiple images.

        Args:
            gt_bboxes (list[Tensor]): Ground truth bboxes for each image with
                shape (num_gts, 4) in [tl_x, tl_y, br_x, br_y] format.
            gt_labels (list[Tensor]): class indices corresponding to each box.
            feat_shape (list[int]): feature map shape with value [B, _, H, W]
            img_shape (list[int]): image shape in [h, w] format.

        Returns:
            tuple[dict,float]: The float value is mean avg_factor, the dict has
               components below:
               - center_heatmap_target (Tensor): targets of center heatmap, \
                   shape (B, num_classes, H, W).
               - wh_target (Tensor): targets of wh predict, shape \
                   (B, 2, H, W).
               - offset_target (Tensor): targets of offset predict, shape \
                   (B, 2, H, W).
               - wh_offset_target_weight (Tensor): weights of wh and offset \
                   predict, shape (B, 2, H, W).
        """
        img_h, img_w = img_shape[:2]
        bs, _, feat_h, feat_w = feat_shape

        width_ratio = float(feat_w / img_w)
        height_ratio = float(feat_h / img_h)

        center_heatmap_target = gt_bboxes[-1].new_zeros(
            [bs, self.num_classes, feat_h, feat_w])


        for batch_id in range(bs):
            gt_bbox = gt_bboxes[batch_id]
            gt_label = gt_labels[batch_id]
            center_x = (gt_bbox[:, [0]] + gt_bbox[:, [2]]) * width_ratio / 2
            center_y = (gt_bbox[:, [1]] + gt_bbox[:, [3]]) * height_ratio / 2
            gt_centers = torch.cat((center_x, center_y), dim=1)

            for j, ct in enumerate(gt_centers):
                ctx_int, cty_int = ct.int()
                ctx, cty = ct
                scale_box_h = (gt_bbox[j][3] - gt_bbox[j][1]) * height_ratio
                scale_box_w = (gt_bbox[j][2] - gt_bbox[j][0]) * width_ratio
                radius = gaussian_radius([scale_box_h, scale_box_w],
                                         min_overlap=self.radiu_overlap)
                radius = max(0, int(radius))
                ind = gt_label[j]
                gen_gaussian_target(center_heatmap_target[batch_id, ind],
                                    [ctx_int, cty_int], radius)


        avg_factor = max(1, center_heatmap_target.eq(1).sum())
        return center_heatmap_target, avg_factor

from math import sqrt
def gaussian_radius(det_size, min_overlap):
    height, width = det_size

    a1 = 1
    b1 = (height + width)
    c1 = width * height * (1 - min_overlap) / (1 + min_overlap)
    sq1 = sqrt(b1**2 - 4 * a1 * c1)
    r1 = (b1 - sq1) / (2 * a1)

    a2 = 4
    b2 = 2 * (height + width)
    c2 = (1 - min_overlap) * width * height
    sq2 = sqrt(b2**2 - 4 * a2 * c2)
    r2 = (b2 - sq2) / (2 * a2)

    a3 = 4 * min_overlap
    b3 = -2 * min_overlap * (height + width)
    c3 = (min_overlap - 1) * width * height
    sq3 = sqrt(b3**2 - 4 * a3 * c3)
    r3 = (b3 + sq3) / (2 * a3)
    return max(r1, r2, r3)